# 2021_DeepLearning
2021-1 DeepLearning course(HUFS)
* https://github.com/rickiepark/handson-ml2
